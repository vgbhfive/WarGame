from wargame.attackoftheorcs import AttackOfTheOrcs

# Main类
if __name__ == '__main__':
    game = AttackOfTheOrcs()
    # 开始游戏
    game.play()